⚒️ OreBorn - Como Jogar
Obrigado por baixar o OreBorn! Este é um guia rápido para você começar sua jornada de sobrevivência.

🚀 Como Iniciar o Jogo
Extraia o arquivo .zip: Não tente rodar o jogo de dentro da pasta compactada. Extraia tudo para uma pasta de sua preferência.

Abra a pasta: Você verá o arquivo chamado OreBorn.

Execute o jogo: Basta dar um clique duplo no arquivo OreBorn.

Nota: Se o Windows exibir um aviso de "O Windows protegeu o seu computador" (SmartScreen), clique em "Mais informações" e depois em "Executar assim mesmo". Isso acontece porque o executável não possui uma assinatura digital paga.

⚠️ Requisitos Importantes
Não mova o executável sozinho: Para o jogo funcionar (especialmente os sons e músicas), o arquivo OreBorn deve estar sempre na mesma pasta que a pasta arquives.

Sistema: Compatível com Windows.

🎮 Controles Básicos
Movimentação: Teclas A e D.

Pular: Tecla W ou Espaço.

Ação (Minerar/Atacar): Botão Esquerdo do Mouse.

Construir: Botão Direito do Mouse (com um bloco selecionado).

Inventário: Tecla E (abre e fecha).

Inventário do Criativo: Tecla I (abre e fecha).

Trocar Item: Tecla Q.

Sair: Tecla Esc.

💡 Dicas de Sobrevivência
Fome: Fique de olho na sua barra de fome. Se ela esvaziar, você começará a perder vida! Procure comida logo no início.

Noite: Monstros aparecem no escuro. Construa um abrigo ou prepare-se para lutar quando o sol se puser.

Crafting: Pressione E para ver o que você pode criar com os materiais que minerou.

Desenvolvido em Python (Tkinter). Aproveite o mundo de OreBorn!